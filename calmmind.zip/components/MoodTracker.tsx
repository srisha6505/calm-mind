import React, { useState } from 'react';
import { MoodEntry } from '../types';
import { LineChart, Line, ResponsiveContainer, YAxis, Tooltip } from 'recharts';
import { Save, Meh, Frown, Smile } from 'lucide-react';

interface MoodTrackerProps {
  history: MoodEntry[];
  onSave: (score: number) => void;
}

export const MoodTracker: React.FC<MoodTrackerProps> = ({ history, onSave }) => {
  const [currentMood, setCurrentMood] = useState(5);

  const getMoodIcon = (score: number) => {
    if (score <= 3) return <Frown className="w-6 h-6 text-red-500 dark:text-red-400" />;
    if (score <= 7) return <Meh className="w-6 h-6 text-yellow-500 dark:text-yellow-400" />;
    return <Smile className="w-6 h-6 text-green-500 dark:text-green-400" />;
  };

  const data = history.map((h, i) => ({ 
    name: i, 
    value: h.score 
  })).slice(-7); // Last 7 entries

  return (
    <div className="bg-white dark:bg-dark-800 border border-stone-200 dark:border-dark-700 rounded-3xl p-6 flex flex-col gap-5 shadow-soft dark:shadow-xl transition-colors duration-300">
      <div className="flex justify-between items-center">
        <h3 className="text-stone-800 dark:text-slate-200 font-bold text-sm tracking-wide uppercase">Mood Tracker</h3>
        <span className="text-xs bg-stone-100 dark:bg-dark-700 text-primary-600 dark:text-primary-400 px-2.5 py-1 rounded-lg border border-stone-200 dark:border-dark-600 font-medium">Daily check-in</span>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
            <p className="text-stone-500 dark:text-slate-400 text-sm font-medium">How are you feeling right now?</p>
            <div className="relative pt-8 pb-2 px-1">
                <div className="flex justify-between text-xs text-stone-400 dark:text-slate-500 mb-3 font-medium">
                    <span>Low</span>
                    <span>Okay</span>
                    <span>High</span>
                </div>
                <input 
                    type="range" 
                    min="1" 
                    max="10" 
                    value={currentMood} 
                    onChange={(e) => setCurrentMood(Number(e.target.value))}
                    className="w-full h-2 bg-stone-200 dark:bg-dark-900 rounded-lg appearance-none cursor-pointer"
                    style={{
                        backgroundImage: 'linear-gradient(to right, #ef4444, #eab308, #22c55e)'
                    }}
                />
                <div 
                    className="absolute top-0 transform -translate-x-1/2 transition-all duration-200 bg-white dark:bg-dark-800 p-1 rounded-full shadow-sm"
                    style={{ left: `${(currentMood - 1) * 11}%` }} // Rough alignment
                >
                    {getMoodIcon(currentMood)}
                </div>
            </div>
        </div>

        <button 
            onClick={() => onSave(currentMood)}
            className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 dark:bg-dark-900 dark:hover:bg-dark-700 border border-stone-200 dark:border-dark-600 rounded-xl flex items-center justify-center text-stone-700 dark:text-slate-300 text-sm font-medium transition-all gap-2 active:scale-[0.98]"
        >
            <Save className="w-4 h-4" />
            Save mood
        </button>
      </div>

      <div className="pt-5 border-t border-stone-100 dark:border-dark-700">
        <p className="text-xs text-stone-400 dark:text-slate-500 mb-4 font-medium uppercase tracking-wider">Recent History</p>
        <div className="h-24 w-full">
            {history.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={data}>
                        <YAxis hide domain={[1, 10]} />
                        <Tooltip 
                            contentStyle={{ 
                                backgroundColor: 'var(--tw-content-bg, #151E32)', 
                                borderColor: 'var(--tw-content-border, #334155)', 
                                color: 'var(--tw-content-color, #F1F5F9)', 
                                fontSize: '12px',
                                borderRadius: '8px',
                                padding: '8px 12px',
                                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                            }}
                            itemStyle={{ color: '#60A5FA' }}
                            cursor={{stroke: '#94a3b8', strokeWidth: 1, strokeDasharray: '4 4'}}
                        />
                        <Line 
                            type="monotone" 
                            dataKey="value" 
                            stroke="#60A5FA" 
                            strokeWidth={2.5} 
                            dot={{ r: 4, fill: '#60A5FA', strokeWidth: 0 }} 
                            activeDot={{ r: 6, fill: '#3B82F6' }}
                        />
                    </LineChart>
                </ResponsiveContainer>
            ) : (
                <div className="h-full flex flex-col items-center justify-center text-stone-400 dark:text-slate-600 text-xs gap-2">
                    <div className="w-12 h-1 bg-stone-200 dark:bg-dark-700 rounded-full" />
                    <span className="italic">No entries yet</span>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};