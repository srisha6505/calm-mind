import { CBTStep } from "./types";

export const SYSTEM_INSTRUCTION = `
You are CalmMind, a gentle, empathetic, and structured therapy assistant. 
Your goal is to listen to the user, validate their feelings, and offer grounded support.
Do not act as a licensed professional; if a user expresses self-harm or severe crisis, gently direct them to emergency services immediately.
Keep responses concise, warm, and conversational. Use a soothing tone.
`;

export const INITIAL_MESSAGE = "Hi, I'm CalmMind. I'm here to listen and help you make sense of what you're feeling. You can type freely, start a CBT session, or try a grounding exercise anytime.";

export const CBT_STEPS: CBTStep[] = [
  {
    id: 1,
    title: "Name the Situation",
    question: "What happened or what are you worried might happen?",
    description: "Step 1 — Describe the event objectively."
  },
  {
    id: 2,
    title: "Identify Feelings",
    question: "What emotions are you feeling right now, and how intense are they (0-100%)?",
    description: "Step 2 — Label your emotions."
  },
  {
    id: 3,
    title: "Identify Thoughts",
    question: "What specific thoughts are going through your mind?",
    description: "Step 3 — Catch the automatic thoughts."
  },
  {
    id: 4,
    title: "Challenge Thoughts",
    question: "Is there evidence that contradicts this thought? Is there another way to look at it?",
    description: "Step 4 — Examine the evidence."
  },
  {
    id: 5,
    title: "Reframe",
    question: "What is a more balanced or helpful thought?",
    description: "Step 5 — Create a new perspective."
  }
];

export const GROUNDING_EXERCISES = [
  "5-4-3-2-1 Technique: Identify 5 things you see, 4 you touch, 3 you hear, 2 you smell, 1 you taste.",
  "Box Breathing: Inhale for 4s, hold for 4s, exhale for 4s, hold for 4s.",
  "Ice Cube: Hold an ice cube in your hand and focus solely on the sensation of cold.",
  "Feet on Floor: Press your feet firmly into the ground and wiggle your toes. Feel the support."
];
