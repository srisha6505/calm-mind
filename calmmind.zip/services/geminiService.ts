import { GoogleGenAI, Chat } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";

let chatSession: Chat | null = null;

export const getChatSession = () => {
    if (!process.env.API_KEY) {
        console.error("API_KEY is missing");
        return null;
    }

    if (!chatSession) {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        chatSession = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: SYSTEM_INSTRUCTION,
                temperature: 0.7,
            },
        });
    }
    return chatSession;
};

export const sendMessageToGemini = async (message: string): Promise<string> => {
    const session = getChatSession();
    if (!session) {
        return "I'm sorry, I'm having trouble connecting to my services right now. (Missing API Key)";
    }

    try {
        const result = await session.sendMessage({ message });
        return result.text || "I hear you.";
    } catch (error) {
        console.error("Gemini Error:", error);
        return "I'm having a moment of difficulty responding. Please try again in a moment.";
    }
};