import React, { useState, useEffect } from 'react';
import { ChatInterface } from './components/ChatInterface';
import { MoodTracker } from './components/MoodTracker';
import { SupportFlows } from './components/SupportFlows';
import { Message, Sender, MoodEntry } from './types';
import { INITIAL_MESSAGE } from './constants';
import { sendMessageToGemini } from './services/geminiService';
import { Moon, Sun, ShieldCheck } from 'lucide-react';

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: INITIAL_MESSAGE,
      sender: Sender.BOT,
      timestamp: new Date(),
    },
  ]);
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [safeMode, setSafeMode] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    // Check system preference or local storage on mount
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const toggleTheme = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    if (newMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  const handleSendMessage = async (text: string) => {
    // Add user message
    const userMsg: Message = {
      id: Date.now().toString(),
      text,
      sender: Sender.USER,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      // Get response from Gemini
      const responseText = await sendMessageToGemini(text);
      
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: responseText,
        sender: Sender.BOT,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveMood = (score: number) => {
    const newEntry: MoodEntry = {
      score,
      timestamp: Date.now()
    };
    setMoodHistory(prev => [...prev, newEntry]);
  };

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-[#050914] text-stone-800 dark:text-slate-200 transition-colors duration-300 p-4 md:p-6 lg:p-8 flex flex-col gap-6">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between items-center gap-4 py-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center shadow-lg shadow-primary-500/20">
             <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-stone-900 dark:text-white tracking-tight">CalmMind</h1>
            <div className="flex items-center gap-2">
              <span className="text-[10px] border border-stone-300 dark:border-slate-700 rounded px-1.5 py-0.5 text-stone-500 dark:text-slate-400 uppercase tracking-widest font-medium">Therapy Chat</span>
              <span className="hidden md:inline text-xs text-stone-500 dark:text-slate-500 font-medium">— Gentle, structured support.</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
           <button 
             onClick={() => setSafeMode(!safeMode)}
             className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold border transition-all duration-300 ${
               safeMode 
               ? 'bg-green-100 border-green-200 text-green-700 dark:bg-green-900/20 dark:border-green-900 dark:text-green-400' 
               : 'bg-stone-200 border-stone-300 text-stone-500 dark:bg-dark-800 dark:border-slate-700 dark:text-slate-400'
             }`}
           >
             <div className={`w-2 h-2 rounded-full ${safeMode ? 'bg-green-500 dark:bg-green-400' : 'bg-stone-400 dark:bg-slate-500'}`} />
             Safe Space {safeMode ? 'On' : 'Off'}
           </button>
           
           <button 
             onClick={toggleTheme}
             className="flex items-center justify-center w-9 h-9 rounded-full border border-stone-200 dark:border-slate-700 bg-white dark:bg-dark-800 text-stone-600 dark:text-slate-300 hover:bg-stone-100 dark:hover:bg-dark-700 transition-colors shadow-sm"
             aria-label="Toggle theme"
           >
             {isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
           </button>
        </div>
      </header>

      {/* Main Grid */}
      <main className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-7xl mx-auto w-full">
        
        {/* Left Column: Chat (Takes 2/3 on large screens) */}
        <section className="lg:col-span-2 h-full min-h-[600px] flex flex-col">
          <ChatInterface 
            messages={messages} 
            isLoading={isLoading} 
            onSendMessage={handleSendMessage} 
          />
        </section>

        {/* Right Column: Tools (Takes 1/3 on large screens) */}
        <aside className="lg:col-span-1 flex flex-col gap-6 h-full">
          <MoodTracker 
            history={moodHistory} 
            onSave={handleSaveMood} 
          />
          <SupportFlows 
            onSendToChat={handleSendMessage} 
          />
        </aside>

      </main>
    </div>
  );
}